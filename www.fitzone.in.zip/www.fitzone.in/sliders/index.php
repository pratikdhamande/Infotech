<?php
include_once '../connection.php';
?>
<!DOCTYPE HTML>
<html>
<head>
<title>FitZone</title>
<link href="../css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="../css/style.css" rel='stylesheet' type='text/css' />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>

</head>
<body>
	<?php 
include '../admin/header.php';
		 ?>
     
         

       <p>Add Sliders</p>
<form action="slider/upload.php" method="post" enctype="multipart/form-data">
	<input type="file" name="file">
	<button type="submit-slider" name="btn-upload-slider">upload Slider</button>
	</form>
   
        <label>Try to upload files in the size of (1000 * 480) only</label>
       
       <p>Add SubSliders</p>


	<form action="subslider/upload.php" method="post" enctype="multipart/form-data">
	<input type="file" name="file">
	<button type="submit-subslider" name="btn-upload-subslider">upload Subslider</button>
	</form>
    <label>Try to upload files in the size of (210 * 420) only</label>

	     	</center>
	  </div>
	 <?php 
include '../footer.php';
		 ?>
</body>	
</html>