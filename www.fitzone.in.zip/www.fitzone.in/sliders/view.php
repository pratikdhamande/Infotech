<?php
include_once '../connection.php';
?>
<!DOCTYPE HTML>
<html>
<head>
<title>FitZone</title>
<link href="../css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="../css/style.css" rel='stylesheet' type='text/css' />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>

</head>
<body>
    <?php 
include '../admin/header.php';
         ?>
     
    <p>your Sliders</p>

	<table width="80%" border="1" align="center">
    <tr>
    <td>File Name</td>
    <td>File Type</td>
    <td>File Size(KB)</td>
    <td>View</td>
    <td>delete</td>
    </tr>
    <?php
	$sql="SELECT * FROM sliders";
	$result_set=mysqli_query($con , $sql);
	while($row=mysqli_fetch_array($result_set))
	{
		?>
        <tr>
        <td><?php echo $row['file'] ?></td>
        <td><?php echo $row['type'] ?></td>
        <td><?php echo $row['size'] ?></td>
        <td><a href="../sliders/slider/uploads/<?php echo $row['file'] ?>" target="_blank">view</a></td>
        <td>delete </td>
        </tr>
        <?php
	}
	?>
    </table>

    

    <br>
    <p>your SubSliders</p>
    <table width="80%" border="1" align="center">
    <tr>
    <td>File Name</td>
    <td>File Type</td>
    <td>File Size(KB)</td>
    <td>View</td>
    </tr>
    <?php
    $sql="SELECT * FROM subsliders";
    $result_set=mysqli_query($con , $sql);
    while($row=mysqli_fetch_array($result_set))
    {
        ?>
        <tr>
        <td><?php echo $row['file'] ?></td>
        <td><?php echo $row['type'] ?></td>
        <td><?php echo $row['size'] ?></td>
        <td><a href="../sliders/subslider/uploads/<?php echo $row['file'] ?>" target="_blank">view file</a></td>
        </tr>
        <?php
    }
    ?>
    </table>
    
</div>
</center>
      </div>
     <?php 
include '../footer.php';
         ?>
</body> 
</html>