<div class="header">
		<div class="container">
			<div class="row">
			  <div class="col-md-12">
				 <div class="header-left">
					 <div class="logo">
						<a href="../admin/admin.php"><img src="../images/logo.jpg" alt=""/></a>
					 </div>
					 <div class="menu">
						  <a class="toggleMenu" href="#"><img src="../images/nav.png" alt="" /></a>
						    <ul class="nav" id="nav">	
						    	<!-- <li><a href="../admin/admin.php">Total Users</a></li>

						    	<li><a href="../admin/enquries.php">Enquries</a></li>
 -->
							 	<!-- <li class="drop"><a href="../admin/admin.php">Users</a>
							    <ul class="nav" id="nav">
							      <li><a href="../admin/totalusers.php">Total Users</a></li>
							      <li><a href="http://www.g.com">Coding</a></li>
							      <li><a href="http://www.g.com">Design</a></li>
							      <li><a href="http://www.g.com">Web Development</a></li>
							    </ul>
							  </li>

							  <li class="drop"><a href="../admin/admin.php">Enqueries</a>
							    <ul class="nav" id="nav">
							      <li><a href="../admin/totalenqueries.php">Total Enqueries</a></li>
							      <li><a href="http://www.g.com">Coding</a></li>
							      <li><a href="http://www.g.com">Design</a></li>
							      <li><a href="http://www.g.com">Web Development</a></li>
							    </ul>
							  </li>

							  <li class="drop"><a href="../admin/admin.php">settings</a>
							    <ul class="nav" id="nav">
							      <li><a href="http://www.g.com">change main slider</a></li>
							      <li><a href="http://www.g.com">change sub slider</a></li>
							      <li><a href="http://www.g.com">change feactures</a></li> -->
							      <!-- <li><a href="http://www.g.com"></a></li> -->
							    </ul>
							  </li>




							 </ul>

								<div class="clear"></div>
							</ul>
							<script type="text/javascript" src="../js/responsive-nav.js"></script>
				    </div>
	    	    </div>

	           <!-- <div class="header_right">
	           	<ul class="nav" id="nav">
							 	<li class="drop"><a href="../admin/admin.php">profile</a>
							    <ul class="nav" id="nav">
							      <li><a href="http://www.g.com">Change PAssword</a></li>
							      <li><a href="http://www.g.com"></a></li>
							      <li><a href="http://www.g.com"></a></li>
							      <li><a href = "../admin/index.php">Logout</a></li>
							    </ul>
							  </li>
							</ul></div>
	            	 -->
	       </div>
	      </div>
		 </div>
	    </div>
	  </div>
			<div class="content-top">



	