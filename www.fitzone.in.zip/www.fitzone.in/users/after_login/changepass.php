<!DOCTYPE HTML>
<html>
<head>
<title>FitZone</title>
<link href="../../css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="../../css/style.css" rel='stylesheet' type='text/css' />

     </script>
 </head>
<body>
	<?php 
include 'includes/header.php';
include '../../connection.php';
		 ?>
     <div class="main">
      <div class="shop_top">
	     <div class="container">

						<form action="" method="POST"> 
								<div class="register-top-grid">
										<h3>password changing..</h3>
										<div>
											<span>old password</span>
											<input type="password" name="opass" required="" autofocus=""> 
										</div>
										<div>
											<span>new password</span>
											<input type="password" name="npass" required=""> 
										</div>
										<div>
											<span>conform password</span>
											<input type="password" name="ncpass" required=""> 
										</div>	
								</div>
			 <center>
			    <div class="form-submit">
				<input name="submit" type="submit" id="submit" value="change password">
</center>
</form>
			           </div>
			       </div>
		   </div>




<?php 

if( isset($_POST["submit"]))
	{
		$old_pass=$_POST['opass'];
		$new_pass=$_POST['npass'];
		$re_pass=$_POST['ncpass'];

		$sql = "select password from users where email='".$_SESSION['user']."'";
		$userrow=mysqli_query($con , $sql);
		$row = mysqli_fetch_assoc($userrow);
		
			if ($old_pass == $row['password']) 
				{
					if ($old_pass !== $new_pass) 
					{
						if ($new_pass == $re_pass) 
							{			
								$query = "update users set Password = '$new_pass' where email = '".$_SESSION['user']."'";
								$result = mysqli_query($con , $query);

								if ($result) 
										{
											echo "<script>alert('successfully');</script>";
									        	echo "<script>window.location='profile.php'</script>";
										}
										else 
										{
											echo "<script>alert('failed');</script>";
									        	echo "<script>window.location='changepass.php'</script>";
										}
							}
							else echo "<script>alert('Your password should be same'); window.location='changepass.php'</script>";
					}
				else echo "<script>alert('Your old and new password should be different'); window.location='changepass.php'</script>";
				}
				else echo "<script>alert('Your old password is wrong'); window.location='changepass.php'</script>";
	}
?>

	  </div>
	 <?php 
include '../../footer.php';
		 ?>
</body>	
</html>