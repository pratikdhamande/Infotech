<?php
 ob_start();
 session_start();
  // require_once '../../connection.php';
 // if session is not set this will redirect to login page
 if( !isset($_SESSION['user']) )
  {
  header("Location: ../before_login/index.php");
  exit;
 }
 // $res=mysql_query("SELECT * FROM users WHERE email=".$_SESSION['user']);
 // $userRow=mysql_fetch_field($res);
?>

<div class="header">
		<div class="container">
			<div class="row">
			  <div class="col-md-12">
				 <div class="header-left">
					 <div class="logo">
						<a href="userhome.php"><img src="../../images/logo.jpg" alt=""/></a>
					 </div>
					 <div class="menu">
						  <a class="toggleMenu" href="#"><img src="../../images/nav.png" alt="" /></a>
						    <ul class="nav" id="nav">	
						    	<!-- <li><a href="../admin/admin.php">Total Users</a></li>

						    	<li><a href="../admin/enquries.php">Enquries</a></li>
 --><!-- 
							 	<li class="drop"><a href="userhome.php"></a>
							    <ul class="nav" id="nav">
							      <li><a href="../admin/totalusers.php">Total Users</a></li>
							      <li><a href="../admin/adduser.php">add users</a></li>
							      <li><a href="../admin/deleteuser.php">delete users</a></li>
							      <li><a href="http://www.g.com">Web Development</a></li>
							    </ul>
							  </li>

							  <li class="drop"><a href="userhome.php"></a>
							    <ul class="nav" id="nav">
							      <li><a href="../admin/totalenqueries.php">Total Enqueries</a></li>
							      <li><a href="http://www.g.com">Coding</a></li>
							      <li><a href="http://www.g.com">Design</a></li>
							      <li><a href="http://www.g.com">Web Development</a></li>
							    </ul>
							  </li>

							  <li class="drop"><a href="userhome.php"></a>
							    <ul class="nav" id="nav">
							      <li><a href="../sliders/index.php">change home page images</a></li>
							      <li><a href="../sliders/view.php">View home page images</a></li>
							      <li><a href="http://www.g.com">change feactures</a></li>
							      <!-- <li><a href="http://www.g.com"></a></li> -->
							    </ul>
							  </li>
 



							 </ul>

								<div class="clear"></div>
							</ul>
							<script type="text/javascript" src="../js/responsive-nav.js"></script>
				    </div>
	    	    </div>

			           <div class="header_right">
			           <ul class="nav" id="nav">
							 	<li class="drop"><a href="profile.php"><?php echo $_SESSION['user']; ?></a>
							    <ul class="nav" id="nav">
								    <li><a href = "../after_login/profile">Profile</a></li>
								    <li><a href="../after_login/changepass.php">Change PAssword</a></li>						      
	 								<li><a href = "../after_login/logout.php">Logout</a></li>

							    </ul>
							  </li>
							</ul></div>
	            	
	       </div>
	      </div>
		 </div>
	    </div>
	  </div>
			<div class="content-top">