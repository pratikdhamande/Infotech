<!DOCTYPE HTML>
<html>
<head>
<title>FitZone</title>
<link href="../../css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="../../css/style.css" rel='stylesheet' type='text/css' />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>

     </script>
 </head>
<body>
	<?php 
include 'includes/header.php';
include '../../connection.php';
		 ?>
     <div class="main">
      <div class="shop_top">
	     <div class="container">

<?php

$sql = "SELECT * FROM users WHERE email='".$_SESSION['user']."'";
$userrow=mysqli_query($con , $sql);
$row = mysqli_fetch_assoc($userrow);        


  ?>
						<form action="" method="POST"> 
								<div class="register-top-grid">
										<h3>we have your information:-</h3>
										<div>
											<span>First Name</span>
											<input type="text" name="fname" value="<?php echo $row['first_name']; ?>"  > 
										</div>
										<div>
											<span>Last Name</span>
											<input type="text" name="lname" value="<?php echo $row['last_name']; ?>" > 
										</div>
										<div>
											<span>Email Address</span>
											<input type="email" name="email" value="<?php echo $row['email']; ?>""> 
										</div>
										
										<div>
											<span>Mobile</span>
											<input type="text" name="mobile" value="<?php echo $row['mobile']; ?>""> 
										</div>
										<div>
											<span>Reference</span>
											<input type="text" name="reference" value="<?php echo $row['reference']; ?>""> 
										</div>
										<div>
											<span>Age</span>
											<input type="text" name="age" value="<?php echo $row['age']; ?>""> 
										</div>
										
								</div>
			           	</form>
			           </div>
			       </center></form></div></div></div>
		   </div>
	  </div>
	 <?php 
include '../../footer.php';
		 ?>
</body>	
</html>