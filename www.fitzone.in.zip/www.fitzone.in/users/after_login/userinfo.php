<!DOCTYPE HTML>
<html>
<head>
<title>FitZone</title>
<link href="../../css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="../../css/style.css" rel='stylesheet' type='text/css' />
 </head>
<body>
	<?php 
include 'includes/header.php';
include '../../connection.php';

		 
		 $sql = "SELECT * FROM fitness_info WHERE email='".$_SESSION['user']."'";
				$userrow=mysqli_query($con , $sql);
				$row = mysqli_fetch_assoc($userrow);
				      
					if ($row['body_weight'] == !'' || $row['here_for'] == !'') 
					{
						echo "<script>window.location='userhome.php'</script>";
					}
					?>
     <div class="main">
      <div class="shop_top">
	     <div class="container">
						<form action="" method="POST"> 
								<div class="register-top-grid">
										<h3>PERSONAL INFORMATION</h3>
										<div>
											<span>your body weight</span>
											<input type="text" name="bweight" autofocus="" required=""> 
										</div>									
										<div>
											<span>your dream weight</span>
											<input type="text" name="dream_weight" required=""> 
										</div>
										
								</div>


								<center>
								<div class="form-submit">
								<input name="submit" type="submit" id="submit" value="Submit"><br>
							</center>
			           </div>
			           	</form>

							<?php 
							if (isset($_POST["submit"]))
						{
								
								$bodyweight = $_POST['bweight'];
								$dream_weight = $_POST['dream_weight'];
								// $why = $_POST['why'];
								// $email = $_POST['email'];
								// $mobile = $_POST['mobile'];		
								// $reference = $_POST['reference'];
								// $age = $_POST['age'];
								// $password = $_POST['password'];
								// $cpassword = $_POST['cpassword'];
								if ($bodyweight > $dream_weight) {
									$why = 'To loose weight';
								}
								else
									$why = 'To Gain Weight';


								if ($bodyweight - $dream_weight == 1 || -1) {
									$our_analysis = 'you need one month exersise';

								}
								elseif ($bodyweight - $dream_weight == 2 || -2) {
									$our_analysis = 'you need two month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 3 || -3) {
									$our_analysis = 'you need three month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 4 || -4) {
									$our_analysis = 'you need four month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 5 || -5) {
									$our_analysis = 'you need five month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 6 || -6) {
									$our_analysis = 'you need six month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 7 || -7) {
									$our_analysis = 'you need seven month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 8 || -8  ) {
									$our_analysis = 'you need eight month exercise';
									
								}
								if ($bodyweight - $dream_weight == 9 || - 9) {
									$our_analysis = 'you need nine month exersise';

								}
								elseif ($bodyweight - $dream_weight == 10 || -10) {
									$our_analysis = 'you need ten month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 11 || -11) {
									$our_analysis = 'you need eleven month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 12 || - 12) {
									$our_analysis = 'you need one year exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 13 || -13) {
									$our_analysis = 'you need threeten month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 14 || -14) {
									$our_analysis = 'you need fourten month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 15 || -15) {
									$our_analysis = 'you need fiften month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 16 || -16) {
									$our_analysis = 'you need sixten month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 17 || -17) {
									$our_analysis = 'you need seventen month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 18 || -18) {
									$our_analysis = 'you need eighten month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 19 || -19) {
									$our_analysis = 'you need ninenten month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 20 || -20) {
									$our_analysis = 'you need twenty month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 21 || -21) {
									$our_analysis = 'you need twenty one month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 22 || -22) {
									$our_analysis = 'you need twenty two month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 23 || -23) {
									$our_analysis = 'you need twenty three month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 24 || -24) {
									$our_analysis = 'you need two year exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 25 || -25) {
									$our_analysis = 'you need twenty five month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 26 || -26) {
									$our_analysis = 'you need two month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 27 || -27) {
									$our_analysis = 'you need three month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 28 || -28) {
									$our_analysis = 'you need four month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 29 || -29) {
									$our_analysis = 'you need five month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 30 || -30) {
									$our_analysis = 'you need six month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 31 || -31) {
									$our_analysis = 'you need seven month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 32 || -32  ) {
									$our_analysis = 'you need eight month exercise';
									
								}
								if ($bodyweight - $dream_weight == 33 || - 33) {
									$our_analysis = 'you need nine month exersise';

								}
								elseif ($bodyweight - $dream_weight == 34 || -34) {
									$our_analysis = 'you need ten month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 36 || -35) {
									$our_analysis = 'you need three year exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 37 || - 37) {
									$our_analysis = 'you need twelve month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 38 || -38) {
									$our_analysis = 'you need threeten month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 39 || -39) {
									$our_analysis = 'you need fourten month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 40 || -40) {
									$our_analysis = 'you need fiften month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 41|| -41) {
									$our_analysis = 'you need sixten month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 42 || -42) {
									$our_analysis = 'you need seventen month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 43 || -43) {
									$our_analysis = 'you need eighten month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 44 || -44) {
									$our_analysis = 'you need ninenten month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 45 || -45) {
									$our_analysis = 'you need twenty month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 46 || -46) {
									$our_analysis = 'you need twenty one month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 47 || -47) {
									$our_analysis = 'you need twenty two month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 48 || -48) {
									$our_analysis = 'you need four year exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 49 || -49) {
									$our_analysis = 'you need twenty four month exercise';
									
								}
								elseif ($bodyweight - $dream_weight == 50 || -50) {
									$our_analysis = 'you need twenty five month exercise';
									
								}


								$sql = " UPDATE `fitness_info` SET `body_weight` = '".$bodyweight."', `dream_weight` = '".$dream_weight."', `here_for` = '".$why."', `our_analysis` = '".$our_analysis."'
								WHERE `fitness_info`.`email` = '".$_SESSION['user']."'";
									$result = mysqli_query($con , $sql);

									
									if ($result)
									{
										echo "<script>alert('your details is valuable for us.');</script>";
								        	echo "<script>window.location='userhome.php'</script>";
									}
									else 
									{
										echo "<script>alert('Please Check the Fields');</script>";
								        	echo "<script>window.location='userinfo.php'</script>";
									}
						}

						?>
</div>
		   </div>
	  </div>
	 <?php 
include '../../footer.php';
		 ?>
</body>	
</html>