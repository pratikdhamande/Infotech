<!DOCTYPE HTML>
<html>
<head>
<title>FitZone</title>
<link href="../../css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="../../css/style.css" rel='stylesheet' type='text/css' />
</head>
<body>
	<?php 
include 'includes/header.php';
include '../../connection.php';
		 ?>

 <div class="main">
      <div class="shop_top">
	     <div class="container">
						<form action="" method="POST"> 
								<div class="register-top-grid">
										<h3>your body status</h3>
			<?php

				$sql = "SELECT * FROM fitness_info WHERE email='".$_SESSION['user']."'";
				$userrow=mysqli_query($con , $sql);
				$row = mysqli_fetch_assoc($userrow);
				      
					if ($row['body_weight'] == '' || $row['here_for'] == '') 
					{
						echo "<script>window.location='userinfo.php'</script>";
					}

					else
					{

						$sql = "SELECT gender FROM users WHERE email='".$_SESSION['user']."'";
						$userrow=mysqli_query($con , $sql);
						$row = mysqli_fetch_assoc($userrow);
						      
							if ($row['gender'] == 'Male') 
							{
								echo " <img src='../../images/man.jpeg'>";
							}

							elseif ($row['gender'] == 'Female')
							{
								echo "<img src='../../images/girl.png' height = '400' width = '500'>";
					}		}
 			 ?>

 				 <?php
				$sql = "SELECT * FROM fitness_info WHERE email='".$_SESSION['user']."'";
				$userrow=mysqli_query($con , $sql);
				$data = mysqli_fetch_assoc($userrow);
				      ?>
										<div>
											<span>total body weight</span>
											<input type="text" name="totalweight" value="<?php echo $data['body_weight']; ?>" >
											<span>your deram weight </span>
											<input type="text" name="totalweight" value="<?php echo $data['dream_weight']; ?>" > 
											<span>you are here for </span>
											<input type="text" name="totalweight" value="<?php echo $data['here_for']; ?>" >
											<span>our weight analysis </span>
											<input type="text" name="totalweight" value="<?php echo $data['our_analysis']; ?>" > 
										
										</div>					 
										
 										






 				
				</div>
				</form>
				</div>
				</div>
				</div>
				</div>
	 
		 <?php 
include '../../footer.php';
		 ?>
		</body>
		</html>