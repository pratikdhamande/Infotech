<?php
session_start();
if (session_destroy()) {
	$_SESSION['user']="";
	header("Location: ../before_login/index.php");
}
exit();
 ?>
