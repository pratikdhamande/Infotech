	<div class="header">	
			<div class="container"> 
			<div class="logo">
						<a href="../../index"><img src="../../images/logo.jpg" alt=""/></a>
				 </div>
				 <div class="menu">
						  <a class="toggleMenu" href="#"><img src="images/nav.png" alt="" /></a>
						    <ul class="nav" id="nav">
						    	<li><a href="../../index">Home</a></li>
						    	<li><a href="../../register">Register</a></li>
						    	<li><a href="../../enquery">Enquery</a></li>
						    	<li><a href="../../contact">Contact Us</a></li>	
						    	<li><a href="index.php">login </a></li>						
							
							</ul>
							<script type="text/javascript" src="js/responsive-nav.js"></script>
				    </div>
				     <div class="header_right">
				     	<!-- <img src="images/sidebar.jpg" alt=""/><script type="text/javascript" src="js/responsive-nav.js"></script></a> -->						
	    		  
	    	    </div>	
	       </div>	
	      </div>	
		 </div>	


	    </div>
	</div>