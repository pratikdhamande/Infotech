<!DOCTYPE HTML>
<html>
<head>
<title>Login</title>
<link href="../../css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="../../css/style.css" rel='stylesheet' type='text/css' />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href='../../http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
</head>
<body>
	<div class="header">
		<div class="container">
			<div class="row">
			  <div class="col-md-12">
				 <div class="header-left">
					 <?php 
include 'header.php';
		 ?>
					
	    	    </div>
	       </div>
	      </div>
		 </div>
	    </div>
	  </div>
     <div class="main">
      <div class="shop_top">
		<div class="container">
				<div class="col-md-6">
				 <div class="login-title">
	           		<h4 class="title">Login</h4>
					<div id="loginbox" class="loginbox">
						<form  action="process.php" method="POST" name="login" id="login-form">
						  <fieldset class="input">
						    <p >
						      <label>Email</label>
						      <input type="email" name="email"  id="email" class="inputbox" size="18" autocomplete="" required="">
						    </p>
						    <p>
						      <label>Password</label>
						      <input id="password" type="password" name="password" class="inputbox" size="18" autocomplete="off" required="">
						    </p>
						    <div class="remember">
							    
							    <input type="submit" name="Submit" class="button" id="btn" value="Login"><div class="clear"></div>
							 </div>
						  </fieldset>

						 </form>

		



					</div>
			      </div>
				 <div class="clear"></div>
			  </div>
			</div>
		  </div>
	  </div>
	  <?php 
include '../../footer.php';
		 ?>
</body>	
</html>