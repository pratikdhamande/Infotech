<?php

session_start();
require_once '../../connection.php';
	if ((!isset($_POST['email'])) || (!isset($_POST['password'])))
	{
		header('Location: ../users/before_login/index');
		exit();
	}


	else
		{

			$username = $_POST['email'];
			$password = $_POST['password'];

			$username = stripcslashes($username);
			$password = stripcslashes($password);
			$username = mysqli_real_escape_string($con , $username);
			$password = mysqli_real_escape_string($con , $password);


			$sql = ("select * from users where email = '$username' and password = '$password'");
			$result=mysqli_query($con , $sql);
			$row = mysqli_fetch_array($result);

			if ($row['email'] == $username && $row['password'] == $password)
				{
					$_SESSION['user']=$username;
					// $_SESSION['password']=$password;
				
					echo "<script>window.location='../after_login/userhome'</script>";
				}
			else
				{
			        echo "<script>alert('Incorrect Username and Password');</script>";
			        	echo "<script>window.location='../before_login/index'</script>";

				}
		}
 ?>