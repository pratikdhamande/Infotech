<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>FitZone</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script src="js/jquery.min.js"></script>

 </head>
<body>
	<?php 
include 'header.php';
		 ?>
     <div class="main">
      <div class="shop_top">
		<div class="container">
			<div class="row">
				<div class="col-md-7">



					


				  <div class="map">
					<iframe width="100%" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.co.in/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=Paranjpe+Colony,+FL,+Maharashtra&amp;aq=4&amp;oq=light&amp;sll=20.9402107,77.7767615&amp;sspn=0.04941,0.104628&amp;ie=UTF8&amp;hq=&amp;hnear=Paranjpe+Colony,+Broward,+Florida,+Maharashtra&amp;t=m&amp;z=14&amp;ll=20.9402107,77.7767615&amp;output=embed"></iframe><br><small><a href="https://maps.google.co.in/maps?f=q&amp;source=embed&amp;hl=en&amp;geocode=&amp;q=Paranjpe+Colony,+FL,+Maharashtra&amp;aq=4&amp;oq=light&amp;sll=20.9402107,77.7767615&amp;sspn=0.04941,0.104628&amp;ie=UTF8&amp;hq=&amp;hnear=Paranjpe+Colony,+Broward,+Florida,+Maharashtra&amp;t=m&amp;z=14&amp;ll=20.9402107,77.7767615" style="color:#666;text-align:left;font-size:12px"></a></small>
				  </div>
				</div>
				<div class="col-md-5">
					<p class="m_8">Welcome to Fitzone, Our mission is to help you reach your fitness and wellness goals for a better life.</p>
					<div class="address">
				                <p>500 Lorem Ipsum Dolor Sit,</p>
						   		<p>22-56-2-9 Sit Amet, Lorem,</p>
						   		<p>USA</p>
				   		<p>Phone:(00) 222 666 444</p>
				   		<p>Fax: (000) 000 00 00 0</p>
				 	 	<p>Email: <span>support[at]snow.com</span></p>
				   		<p>Follow on: <span>Facebook</span>, <span>Twitter</span></p>
				   </div>
				</div>
			</div>
			
	     </div>
	   </div>
	  </div>
	  <?php 
include 'footer.php';
		 ?>
</body>	
</html>