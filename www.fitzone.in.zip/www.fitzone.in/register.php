<!DOCTYPE HTML>
<html>
<head>
<title>FitZone</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>

     </script>
 </head>
<body>
	<?php 
include 'header.php';
		 ?>
     <div class="main">
      <div class="shop_top">
	     <div class="container">
						<form action="" method="POST"> 
								<div class="register-top-grid">
										<h3>PERSONAL INFORMATION</h3>
										<div>
											<span>First Name</span>
											<input type="text" name="fname" autofocus="" required=""> 
										</div>
										<div>
											<span>Last Name</span>
											<input type="text" name="lname" required=""> 
										</div>

										<div>
											<input type="radio" name="sex" value="Male" required=""> Male
										</div>
										<div>
											<input type="radio" name="sex" value="Female" required=""> Female
										</div>
										<!-- <div>
											<span>Gender</span>
											<input type="text" name="gender" required=""> 
										</div> -->
										<div>
											<span>Email Address</span>
											<input type="email" name="email" required=""> 
										</div>
										
										<div>
											<span>Mobile</span>
											<input type="text" name="mobile" required=""> 
										</div>
										<div>
											<span>Reference</span>
											<input type="text" name="reference" required=""> 
										</div>
										<div>
											<span>Age</span>
											<input type="text" name="age" required=""> 
										</div>
										<div>
											<span>password</span>
											<input type="password" name="password" required=""> 
										</div>
										<div>
											<span>conform password</span>
											<input type="password" name="cpassword" required=""> 
										</div>
								</div>


								<center>
								<div class="form-submit">
								<input name="submit" type="submit" id="submit" value="Submit"><br>
							</center>
			           </div>
			           	</form>



							<?php 

							if (isset($_POST["submit"]))
						 {

								include 'connection.php';

								$fname = $_POST['fname'];
								$lname = $_POST['lname'];
								$gender = $_POST['sex'];
								$email = $_POST['email'];
								$mobile = $_POST['mobile'];		
								$reference = $_POST['reference'];
								$age = $_POST['age'];
								$password = $_POST['password'];
								$cpassword = $_POST['cpassword'];

								if ($password == $cpassword)
							{
								
								$sql = "SELECT * FROM `users` WHERE mobile =".$mobile."";
								$result = mysqli_query($con , $sql);
								$numrows = mysqli_fetch_assoc($result);
								if ($numrows == 0) 
								{
									$insert_data = "INSERT into users (`first_name`, `last_name`, `gender`, `email`, `mobile`, `reference`, `age`, `password`, `date`) values
									('".$fname."','".$lname."', '".$gender."', '".$email."',".$mobile.",'".$reference."',".$age.",'".$password."',NOW())";

									$insert_email = "INSERT into `fitness_info` (`email`) 
									VALUES ('".$email."')";
									

                                    if ($con->query($insert_data) === TRUE && $con->query($insert_email) === TRUE)
									{	

										echo "<script>alert('Thanks for register');</script>";
								        	echo "<script>window.location='index.php'</script>";
									}

									else 
									{	
										echo "<script>alert('Please Check the Fields');</script>";
								        	echo "<script>window.location='register.php'</script>";
									}


								}
								else 
								{
									echo "<script>alert('user alwready register')</script>";
								}
							}

							else echo "<script>alert('password should be same ')</script>";
	
						}
							
						?>
</div>
		   </div>
	  </div>
	 <?php 
include 'footer.php';
		 ?>
</body>	
</html>