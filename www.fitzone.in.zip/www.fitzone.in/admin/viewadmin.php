
<!DOCTYPE HTML>
<html>
<head>
<title>Admin</title>
<link href="../css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="../css/style.css" rel='stylesheet' type='text/css' />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
</head>
<body>
    
    <?php include "../admin/header.php" ?>  





 <div class="main">
      <div class="shop_top">
         <div class="container">

						<table width="80%" border="1" align="center">
    <tr align="center">
    <td>Admin ID</td>
    <td>Admin Name</td>
    <td>Email</td>
    <td>Mobile</td>
    <td>Password</td>
    <td>Date</td>
    </tr>
    <?php
    include '../connection.php';
	$sql="SELECT * FROM admin";
	$result_set=mysqli_query($con , $sql);
	while($row=mysqli_fetch_array($result_set))
	{
		?>
        <tr align="center">
        <td><?php echo $row['adminID'] ?></td>
        <td><?php echo $row['name'] ?></td>
        <td><?php echo $row['email'] ?></td>
        <td><?php echo $row['mobile'] ?></td>
        <td><?php echo $row['password'] ?></td>
        <td><?php echo $row['date'] ?></td>

        </tr>
        <?php
	}
	?>
    </table>
	  </div></div></div>
	 <?php 
include '../footer.php';
		 ?>
</body>	
</html>