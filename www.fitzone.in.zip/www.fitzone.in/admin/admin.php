<!DOCTYPE HTML>
<html>
<head>
<title>Admin</title>
<link href="../css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="../css/style.css" rel='stylesheet' type='text/css' />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
</head>
<body>
	<?php 
	include "../admin/header.php"
	 ?>	
 <div class="main">
      <div class="shop_top">
	     <div class="container">			

<!-- dada -->

<p>Todays Total Users Register</p>
<table border = "1" width="900" align="center">
<tr>
	<th>User ID</th>
	<th>First Name</th>
	<th>Last Name</th>
	<th>Email</th>
	<th>Mobile</th>
	<th>Reference</th>
	<th>Age</th>
	<th>Date</th>
</tr>

		<?php
			include '../connection.php';
			$SQL = "SELECT * FROM `users` WHERE date = CURDATE()";
			$result = mysqli_query($con , $SQL);
			while ($db_field = mysqli_fetch_assoc($result))
			{	
				$h = $db_field['userID'];
				$a = $db_field['first_name'];
				$b = $db_field['last_name'];
				$c = $db_field['email'];
				$d = $db_field['mobile'];
				$e = $db_field['reference'];
				$f = $db_field['age'];
				$g = $db_field['date'];
				print("<tr>");
				print("<td align = 'center'>$h</td>");
				print("<td align = 'center'>$a</td>");
				print("<td align = 'center'>$b</td>");
				print("<td align = 'center'>$c</td>");
				print("<td align = 'center'>$d</td>");
				print("<td align = 'center'>$e</td>");
				print("<td align = 'center'>$f</td>");
				print("<td align = 'center'>$g</td>");
				print("</tr>");

			}
		?>
</table>
<br>


<p>Todays Total Enquiries</p>
 <table border = "1" width="900" align="center">
<tr>
	<th>Sr.No</th>
	<th>Name</th>
	<th>email</th>
	<th>Mobile</th>
	<th>Subject</th>
	<th>Message</th>
	<th>Date</th>
</tr>
			<?php
				$sql = "SELECT * FROM `enqueries` WHERE date = CURDATE()";
					// $sql = "SELECT * FROM enqueries";
				$result = mysqli_query($con , $sql);
					while ($db_field = mysqli_fetch_assoc($result))
						{ 
							$g = $db_field['ID'];
							$a = $db_field['name'];
							$b = $db_field['email'];
							$c = $db_field['mobile'];
							$d = $db_field['subject'];
							$e = $db_field['message'];
							$f = $db_field['date'];
							print("<tr>");
							print("<td align = 'center'>$g</td>");
							print("<td align = 'center'>$a</td>");
							print("<td align = 'center'>$b</td>");
							print("<td align = 'center'>$c</td>");
							print("<td align = 'center'>$d</td>");
							print("<td align = 'center'>$e</td>");
							print("<td align = 'center'>$f</td>");
							print("</tr>");
						}
			?>
</table>



											<?php 

											$sql = " SELECT COUNT(email) FROM `users` ";
											$result  = mysqli_query($con , $sql);
											$row = mysqli_fetch_assoc($result);        
							 

											$sql = " SELECT COUNT(email) FROM `enqueries` ";
											$result  = mysqli_query($con , $sql);
											$row1 = mysqli_fetch_assoc($result);   

											$sql = " SELECT COUNT(email) FROM `admin` ";
											$result  = mysqli_query($con , $sql);
											$row2 = mysqli_fetch_assoc($result);  

											$sql = " SELECT  SUM(body_weight) FROM `fitness_info` ";
											$result  = mysqli_query($con , $sql);
											$row3 = mysqli_fetch_assoc($result);        
									
											 ?>


										<div class="register-top-grid">
											<div></div>
											<div></div>
										<div>
											<span>total no of people register</span>
											<input type="text" name="fname" value="<?php echo $row['COUNT(email)']; ?>"> 
										</div>
										<div>
											<span>total no of enqueries asked</span>
											<input type="text" name="fname" value="<?php echo $row1['COUNT(email)']; ?>"> 
										</div>
										<div>
											<span>total no of admin account acctivated</span>
											<input type="text" name="fname" value="<?php echo $row2['COUNT(email)']; ?>"> 
										</div>
										<div>
											<span>total amount of body weight we have</span>
											<input type="text" name="fname" value="<?php echo $row3['SUM(body_weight)']; ?> Kfg"> 
										</div>




	  </div>
	  </div>
	</div>
	 <?php 
include '../footer.php';
		 ?>
</body>	
</html>