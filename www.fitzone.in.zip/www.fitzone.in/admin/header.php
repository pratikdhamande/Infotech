<?php
 ob_start();
 session_start();
 // if session is not set this will redirect to login page
 if( !isset($_SESSION['admin']) )
  {
  header("Location: ../admin/index");
  exit;
 }
?>

<div class="header">
		<div class="container">
			<div class="row">
			  <div class="col-md-12">
				 <div class="header-left">
					 <div class="logo">
						<a href="../admin/admin"><img src="../images/logo.jpg" alt=""/></a>
					 </div>
					 <div class="menu">
						  <a class="toggleMenu" href="#"><img src="../images/nav.png" alt="" /></a>
						    <ul class="nav" id="nav">	
						    	<!-- <li><a href="../admin/admin">Total Users</a></li>

						    	<li><a href="../admin/enquries">Enquries</a></li>
 -->
							 	<li class="drop"><a href="../admin/admin">Users</a>
							    <ul class="nav" id="nav">
							      <li><a href="../admin/totalusers">Total Users</a></li>
							      <li><a href="../admin/adduser">add users</a></li>
							      <li><a href="../admin/deleteuser">delete users</a></li>
							      <li><a href="http://www.g.com">Web Development</a></li>
							    </ul>
							  </li>

							  <li class="drop"><a href="../admin/admin">Enqueries</a>
							    <ul class="nav" id="nav">
							      <li><a href="../admin/totalenqueries">Total Enqueries</a></li>
							      <li><a href="http://www.g.com">Coding</a></li>
							      <li><a href="http://www.g.com">Design</a></li>
							      <li><a href="http://www.g.com">Web Development</a></li>
							    </ul>
							  </li>

							<!--   <li class="drop"><a href="../admin/admin">setting</a>
							    <ul class="nav" id="nav">
							      <li><a href="../sliders/index">change home page images</a></li>
							      <li><a href="../sliders/view">View home page images</a></li>
							      <li><a href="http://www.g.com">change feactures</a></li>
							      <!-- <li><a href="http://www.g.com"></a></li> -->
							    </ul> 
							  </li>




							 </ul>

								<div class="clear"></div>
							</ul>
							<script type="text/javascript" src="../js/responsive-nav.js"></script>
				    </div>
	    	    </div>

	           <div class="header_right">
	           	<ul class="nav" id="nav">
							 	<li class="drop"><a href="../admin/admin">profile</a>
							    <ul class="nav" id="nav">
							      <li><a href="../admin/changepass">Change PAssword</a></li>
							      <li><a href="../admin/createadmin">create admin</a></li>
							      <li><a href="../admin/viewadmin">view admin</a></li>
							      <li><a href = "../admin/logout">Logout</a></li>
							    </ul>
							  </li>
							</ul></div>
	            	
	       </div>
	      </div>
		 </div>
	    </div>
	  </div>
			<div class="content-top">



	