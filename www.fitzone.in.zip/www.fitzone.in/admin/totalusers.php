
<!DOCTYPE HTML>
<html>
<head>
<title>Admin</title>
<link href="../css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="../css/style.css" rel='stylesheet' type='text/css' />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
</head>
<body>
	
	<?php include "../admin/header.php" ?>	





 <div class="main">
      <div class="shop_top">
	     <div class="container">			

<!-- dada -->


<table border = "1" width="1000" align="center">
<tr>
	<th>User ID</th>
	<th>First Name</th>
	<th>Last Name</th>
	<th>Email</th>
	<th>Mobile</th>
	<th>Reference</th>
	<th>Age</th>
	<th>Date</th>
</tr>

<?php
include '../connection.php';
$SQL = "SELECT * FROM users \n"
. "ORDER BY `users`.`date` DESC";;
$result = mysqli_query($con , $SQL);

while ($db_field = mysqli_fetch_assoc($result))
{
	$h = $db_field['userID'];
	$a = $db_field['first_name'];
	$b = $db_field['last_name'];
	$c = $db_field['email'];
	$d = $db_field['mobile'];
	$e = $db_field['reference'];
	$f = $db_field['age'];
	$g = $db_field['date'];
	print("<tr>");
	print("<td align = 'center'>$h</td>");
	print("<td align = 'center'>$a</td>");
	print("<td align = 'center'>$b</td>");
	print("<td align = 'center'>$c</td>");
	print("<td align = 'center'>$d</td>");
	print("<td align = 'center'>$e</td>");
	print("<td align = 'center'>$f</td>");
	print("<td align = 'center'>$g</td>");
	print("</tr>");
}
?>
</table>
	   </div></div></div>
	  </div>
	 <?php 
include '../footer.php';
		 ?>
</body>	
</html>