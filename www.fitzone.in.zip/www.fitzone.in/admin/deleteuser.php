<!DOCTYPE HTML>
<html>
<head>
<title>FitZone</title>
<link href="../css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="../css/style.css" rel='stylesheet' type='text/css' />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>

</head>
<body>
	<?php 
include '../admin/header.php';
		 ?>
     <div class="main">
      <div class="shop_top">
	     <div class="container">




	     	</center></div></div></div>   </div>
	  </div>
	 <?php 
include '../footer.php';
		 ?>
</body>	
</html>