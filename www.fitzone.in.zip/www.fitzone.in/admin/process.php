<?php

session_start();
require_once '../connection.php';
	if ((!isset($_POST['email'])) || (!isset($_POST['password'])))
	{
		header('Location: ../admin/index.php');
		exit();
	}


	else
		{

			$username = $_POST['email'];
			$password = $_POST['password'];

			$username = stripcslashes($username);
			$password = stripcslashes($password);
			$username = mysqli_real_escape_string($con,$username);
			$password = mysqli_real_escape_string($con,$password);



			// mysql_connect("localhost","root","");
			// mysql_select_db("fitzone");
			
			$sql = ("select * from admin where email = '$username' and password = '$password'");
			$result=mysqli_query($con , $sql);
			$row = mysqli_fetch_array($result);
			if ($row['email'] == $username && $row['password'] == $password)
				{
					$_SESSION['admin']=$username;
					// $_SESSION['password']=$password;
					
					echo "<script>window.location='../admin/admin.php'</script>";
				}
			else
				{
			        echo "<script>alert('Incorrect Username and Password');</script>";
			        	echo "<script>window.location='../admin/index.php'</script>";

				}
		}
 ?>