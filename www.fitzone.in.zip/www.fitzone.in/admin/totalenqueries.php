
<!DOCTYPE HTML>
<html>
<head>
<title>Admin</title>
<link href="../css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="../css/style.css" rel='stylesheet' type='text/css' />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
</head>
<body>
    
    <?php include "../admin/header.php" ?>  





 <div class="main">
      <div class="shop_top">
         <div class="container">
					
<!-- dada -->


<table border = "1" width="1150" align="center">
<tr>
    <th>Sr.No</th>
	<th>Name</th>
	<th>email</th>
	<th>Mobile</th>
	<th>Subject</th>
	<th>Message</th>
	<th align="center">Date</th>
</tr>

<?php
include '../connection.php';

$sql = "SELECT * FROM `enqueries` \n"
    . "ORDER BY `enqueries`.`date` DESC";


// $sql = "SELECT * FROM enqueries";
$result = mysqli_query($con , $sql);

while ($db_field = mysqli_fetch_assoc($result))
{
    $g = $db_field['ID'];
	$a = $db_field['name'];
	$b = $db_field['email'];
	$c = $db_field['mobile'];
	$d = $db_field['subject'];
	$e = $db_field['message'];
	$f = $db_field['date'];
	print("<tr>");
    print("<td align = 'center'>$g</td>");
	print("<td align = 'center'>$a</td>");
	print("<td align = 'center'>$b</td>");
	print("<td align = 'center'>$c</td>");
	print("<td align = 'center'>$d</td>");
	print("<td align = 'center'>$e</td>");
	print("<td align = 'center'>$f</td>");
	print("</tr>");
}
?>
</table>
	   
	  </div></div></div>
	 <?php 
include '../footer.php';
		 ?>
</body>	
</html>