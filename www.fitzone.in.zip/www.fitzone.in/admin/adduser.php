<!DOCTYPE HTML>
<html>
<head>
<title>FitZone</title>
<link href="../css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="../css/style.css" rel='stylesheet' type='text/css' />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
</head>
<body>
	<?php 
include '../admin/header.php';
		 ?>
     <div class="main">
      <div class="shop_top">
	     <div class="container">

						<form method="POST"> 
								<div class="register-top-grid">
										<h3>PERSONAL INFORMATION</h3>
										<div>
											<span>First Name</span>
											<input type="text" name="fname" autofocus="" required=""> 
										</div>
										<div>
											<span>Last Name</span>
											<input type="text" name="lname" required=""> 
										</div>
										<div>
											<span>Email Address</span>
											<input type="text" name="email" required=""> 
										</div>
										
										<div>
											<span>Mobile</span>
											<input type="text" name="mobile" required=""> 
										</div>
										<div>			
											<span>Reference</span>
											<input type="text" name="reference" required=""> 
										</div>
										<div>
											<span>Age</span>
											<input type="text" name="age" required=""> 
										</div>
								</div>
								<center>

								<div class="form-submit">
								<input name="submit" type="submit" id="submit" value="add user"><br>
			           </div>
			           	</form>



							<?php 

							if (isset($_POST["submit"]))
						 {

								include '../connection.php';

								$fname = $_POST['fname'];
								$lname = $_POST['lname'];
								$email = $_POST['email'];
								$mobile = $_POST['mobile'];		
								$reference = $_POST['reference'];
								$age = $_POST['age'];

								

								$sql = "SELECT * FROM `users` WHERE mobile =".$mobile."";
								$numrows = mysql_set_charset($sql);
								if ($numrows == 0) 
								{
									$sql = "INSERT into `users` (userID, first_name, last_name, email, mobile, reference, age, date)  values('','".$fname."','".$lname."','".$email."',".$mobile.",'".$reference."',".$age.",NOW())";

									$result = mysql_query($sql);


									if ($result) 
									{
										echo "<script>alert('User added successfull..');</script>";
								        	echo "<script>window.location='../admin/adduser.php'</script>";
									}
									else 
									{
										echo "<script>alert('Please Check the Fields');</script>";
								        	echo "<script>window.location='../admin/adduser.php'</script>";
									}


								}
								else 
								{
									echo "<script>alert('user alwready register')</script>";
								}
		
	
							}


?>					</div>
		</center></div></div></div>   </div>
	  </div>
	 <?php 
include '../footer.php';
		 ?>
</body>	
</html>