<?php
session_start();
if (session_destroy()) {
	$_SESSION['admin']="";
	header("Location: ../admin/index");
}
exit();
 ?>
