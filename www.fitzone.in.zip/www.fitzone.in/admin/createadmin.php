
<!DOCTYPE HTML>
<html>
<head>
<title>Admin</title>
<link href="../css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="../css/style.css" rel='stylesheet' type='text/css' />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
</head>
<body>
	
	<?php include "../admin/header.php" ?>	





 <div class="main">
      <div class="shop_top">
	     <div class="container">

						<form method="POST"> 
								<div class="register-top-grid">
										<h3>Admin Creation </h3>
										
										
										<div>
											<span>Name</span>
											<input type="text" name="name" required=""> 
										</div>
										<div>
											<span>Email Address</span>
											<input type="email" name="email" required=""> 
										</div>
										
										<div>
											<span>Mobile</span>
											<input type="text" name="mobile" required=""> 
										</div>
										<div>
											<span>password</span>
											<input type="password" name="password" required=""> 
										</div>
										<div>
											<span>conform password</span>
											<input type="password" name="cpassword" required=""> 
										</div>
										</div>
								<center>

								<div class="form-submit">
								<input name="submit" type="submit" id="submit" value="add admin"><br>
			           </div>
			           	</form>



							<?php 

							if (isset($_POST["submit"]))
						 {

								include '../connection.php';
								
								$name = $_POST['name'];
								$email = $_POST['email'];
								$mobile = $_POST['mobile'];		
								$password = $_POST['password'];
								$cpassword = $_POST['cpassword'];
							
							if ($password == $cpassword)
							{
								$sql = "SELECT * FROM `admin` WHERE mobile =".$mobile."";
								$numrows = mysql_set_charset($sql);
								if ($numrows == 0) 
								{
									$sql = "INSERT into admin (name,email,mobile,password,date) values ('".$name."','".$email."',".$mobile.",'".$password."',NOW())";
									
									$result = mysql_query($sql);


									if ($result) 
									{
										echo "<script>alert('Admin created ');</script>";
								        	echo "<script>window.location='../admin/admin.php'</script>";
									}
									else 
									{
										echo "<script>alert('Please Check the Fields');</script>";
								        	echo "<script>window.location='../admin/createadmin.php'</script>";
									}


								}
								else 
								{
									echo "<script>alert('admin already created ')</script>";
								}
		
							}
							else echo "<script>alert('password should be same ')</script>";

							}


?>					</div>
		</center></div></div></div>   </div>
	  </div>
	 <?php 
include '../footer.php';
		 ?>
</body>	
</html>