<?php

 $con = new MySQLi('localhost' , 'root' , '' , 'fitzone college');
if ( mysqli_connect_errno() ) {
  header('Location: error/database');
  die();
 }
 
 ?>