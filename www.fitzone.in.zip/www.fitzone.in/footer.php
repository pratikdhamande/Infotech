<div class="footer">
			<div class="container">
				<div class="row">
					<div class="col-md-3">
						<ul class="footer_box">
							<h4>We Support</h4>
							<li><!-- <a href="#"> -->Mens</a></li>
							<li><!-- <a href="#"> -->Womens</a></li>
							<li><!-- <a href="#"> -->Youth</a></li> 
						</ul>
					</div>
					<div class="col-md-3">
						<ul class="footer_box">
							<h4>About</h4>
							<li><!-- <a href="#"> -->Careers and internships</a></li>
							<li><!-- <a href="#"> -->Sponserships</a></li>
							<li><!-- <a href="#"> -->team</a></li>
							<li><!-- <a href="#"> -->Catalog Request/Download</a></li>
						</ul>
					</div>
					<div class="col-md-3">
						<ul class="footer_box">
							<h4>Customer Support</h4>
							<li><!-- <a href="#"> -->Contact Us</a></li>
							<li><!-- <a href="#"> -->Easy Returns</a></li>
							<li><!-- <a href="#"> -->Warranty</a></li>
							<li><!-- <a href="#"> -->Replacement Binding Parts</a></li>
						</ul>
					</div>
					<div class="col-md-3">
						<ul class="footer_box">
							<h4>Follow US on</h4>
							<ul class="social">	
							  <li class="facebook"><a href="https://www.facebook.com/coach5k/" target="_blank"><span> </span></a></li>
<!-- 							  <li class="twitter"><a href="#"><span> </span></a></li>
 -->							  <li class="instagram"><a href="#" target="_blank"><span> </span></a></li>
<!-- 							  <li class="youtube"><a href="#"><span> </span></a></li>										  				
 -->						    </ul>
		   					
						</ul>
					</div>
				</div>
				<div class="row footer_bottom">
				    <div class="copy">
			           <p>© 2017 Design by <a href="https://www.facebook.com/pdhamande" target="_blank">Pratik Dhamande</a></p>
		            </div>
   				 </div>
			</div>
		</div>