<div class="header">	
			<div class="container"> 
			<div class="logo">
						<a href="index.php"><img src="images/logo.jpg" alt=""/></a>
				 </div>
				 <div class="menu">
						  <a class="toggleMenu" href="#"><img src="images/nav.png" alt="" /></a>
						    <ul class="nav" id="nav">
						    	<li><a href="index.php">Home</a></li>
						    	<li><a href="register.php">Register</a></li>
						    	<li><a href="enquery.php">Enquiry</a></li>
						    	<li><a href="contact.php">Contact Us</a></li>	
						    	<li><a href="users/before_login/index.php">login </a></li>						
							
							</ul>
							<script type="text/javascript" src="js/responsive-nav.js"></script>
							<script type="text/javascript" src="../js/alart.js"></script>
							<link rel="stylesheet" type="text/css" href="../css/style_alart.css">
				    </div>
				     <div class="header_right">
				     	<!-- <img src="images/sidebar.jpg" alt=""/><script type="text/javascript" src="js/responsive-nav.js"></script></a> -->						
	    		  
	    	    </div>	
	       </div>	
	      </div>	
		 </div>	


	    </div>
	</div>