<!DOCTYPE HTML>
<html>
<head>
<title>FitZone</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
</head>
<body>
	<?php 
include 'header.php';
		 ?>
     <div class="main">
      <div class="shop_top">
		<div class="container">
			<div class="row ex_box">
						<form action="" method="POST"> 
								<div class="register-top-grid">
										<h3>Enquiry Portal</h3>
										<div>
											<span>Name</span>
											<input type="text" name="name" required=""> 
										</div>
										<div>
											<span>Email</span>
											<input type="text" name="email" required=""> 
										</div>
										<div>
											<span>Mobile</span>
											<input type="text" name="mobile" required=""> 
										</div>
										
										<div>
											<span>Subject</span>
											<input type="text" name="subject" required=""> 
										</div>
										<div>
											<span>Message</span>
											<textarea type="text" name="message" required=""> </textarea>
										</div>
								</div>
								
								<div class="form-submit">
								<input name="submit" type="submit" id="submit" value="Submit"><br>	       
			           </div>
			           </div>
			           	</form>

			           <?php 

							if (isset($_POST["submit"]))
						 {


								include 'connection.php';

								$Name = $_POST['name'];
								$Email = $_POST['email'];
								$Mobile = $_POST['mobile'];		
								$Subject = $_POST['subject'];
								$Message = $_POST['message'];

								$sql = "INSERT into enqueries (`name`, `email`, `mobile`, `subject`, `message`, `date`)
								values('".$Name."','".$Email."',".$Mobile.",'".$Subject."','".$Message."',NOW())";
								$query = mysqli_query($con , $sql);

								if(!$query)
								{
									echo "<script>alert('Please Check the Fields');</script>";
									echo "<script>window.location='enquery.php'</script>";
								}
								else
								{
									echo "<script>alert('Thanks we contact you soon...');</script>";
									echo "<script>window.location='index.php'</script>";
								}
						}		
					 ?>




		</div>
	</div>
</div>
</div>

	 <?php 
include 'footer.php';
		 ?>
</body>	
</html>